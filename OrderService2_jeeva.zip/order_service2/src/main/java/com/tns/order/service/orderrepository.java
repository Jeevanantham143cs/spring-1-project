package com.tns.order.service;

public interface orderrepository {

}
