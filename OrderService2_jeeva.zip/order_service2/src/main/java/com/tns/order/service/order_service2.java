package com.tns.order.service;

import jakarta.persistence.Entity;

@Entity
public class order_service2 {

}
